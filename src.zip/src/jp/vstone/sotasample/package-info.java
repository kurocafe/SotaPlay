/**
 * Sota用ロボット制御サンプルソース
 */
package jp.vstone.sotasample;

