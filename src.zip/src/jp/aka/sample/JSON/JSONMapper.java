package jp.aka.sample.JSON;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONMapper {
	public static final ObjectMapper mapper = new ObjectMapper();
}
