package jp.aka.sample.values;

public class GenerateReq {
	private String user_message;

	public String getUser_message() {
		return user_message;
	}

	public void setUser_message(String user_message) {
		this.user_message = user_message;
	}
	
}
