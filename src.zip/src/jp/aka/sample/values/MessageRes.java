package jp.aka.sample.values;

public class MessageRes {
	private String response;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}


}
